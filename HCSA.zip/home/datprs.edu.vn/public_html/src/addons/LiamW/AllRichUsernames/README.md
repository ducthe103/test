# All Rich Usernames

Simple XenForo 2.x add-on that changes all username calls to display them using the usergroup styling.

**Note: This add-on may cause a large increase in per-page queries if the required data needs to be fetched.**

**Note: This repository is for development purposes. Please download the latest release from the releases tab or https://xenforo.com/resources.**