<?php
/**
 * MJ add-on's core for the event listener.
 *
 * @package MJCore
 * Version 1.0.0
 */

namespace MJCore;
Helpers::requireLibrary(__FILE__);